const http = require('http');
const WebSocket = require('ws');
const PORT = process.env.PORT || 10000;
const MAX_PLAYERS = Number(process.env.MAX_PLAYERS || 15);
const rooms = new Map();
const clients = new Map();

const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, {'content-type':'application/json'});
    res.end(JSON.stringify({ok:true, service:'Boom Survival relay', rooms:rooms.size, players:clients.size, maxPlayers:MAX_PLAYERS}));
  } else { res.writeHead(404); res.end('Not found'); }
});
const wss = new WebSocket.Server({ server, maxPayload: 64 * 1024 });
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function roomPlayers(room) { return [...(rooms.get(room)||[])].filter(c=>c.readyState===WebSocket.OPEN); }
function broadcast(room, obj, except=null) { for (const c of roomPlayers(room)) if (c!==except) send(c,obj); }
function roster(room) { return roomPlayers(room).map(c=>({id:c.uid,name:c.name,position:c.position,hp:c.hp})); }
function remove(ws) {
  const r=ws.room; if (!r) return;
  const set=rooms.get(r); if(set){set.delete(ws); if(!set.size) rooms.delete(r);}
  clients.delete(ws.uid);
  broadcast(r,{t:'leave',id:ws.uid});
  broadcast(r,{t:'roster',players:roster(r)});
  ws.room=null;
}
wss.on('connection',(ws)=>{
  ws.uid=Math.random().toString(36).slice(2,10); ws.room=null; ws.name='Player'; ws.position=null; ws.hp=100;
  send(ws,{t:'hello',id:ws.uid,maxPlayers:MAX_PLAYERS});
  ws.on('message',(buf)=>{
    let m; try {m=JSON.parse(buf.toString());} catch {return;}
    if(!m || typeof m.t!=='string') return;
    if(m.t==='join'){
      const room=String(m.room||'main').replace(/[^a-zA-Z0-9_-]/g,'').slice(0,32)||'main';
      if(ws.room) remove(ws);
      const set=rooms.get(room)||new Set();
      if(set.size>=MAX_PLAYERS){send(ws,{t:'error',code:'room_full',message:'Room is full (15 players max)'});return;}
      ws.room=room; ws.name=String(m.name||'Guest').replace(/[<>]/g,'').slice(0,18); set.add(ws); rooms.set(room,set); clients.set(ws.uid,ws);
      send(ws,{t:'joined',room,id:ws.uid,players:roster(room)});
      broadcast(room,{t:'join',player:{id:ws.uid,name:ws.name,position:ws.position,hp:ws.hp}},ws);
      broadcast(room,{t:'roster',players:roster(room)});
      return;
    }
    if(!ws.room) return;
    if(m.t==='player'){
      if(Array.isArray(m.p)&&m.p.length===3&&m.p.every(v=>Number.isFinite(v))){ws.position=m.p.map(v=>Math.max(-100000,Math.min(100000,v)));}
      if(Number.isFinite(m.h))ws.hp=Math.max(0,Math.min(100,m.h));
      broadcast(ws.room,{t:'player',id:ws.uid,n:ws.name,p:ws.position,h:ws.hp},ws);
    } else if(m.t==='chat'){
      const msg=String(m.m||'').slice(0,120); if(msg)broadcast(ws.room,{t:'chat',id:ws.uid,n:ws.name,m:msg});
    } else if(m.t==='give'){
      // Relay admin command only; the game client must still enforce who can use it.
      broadcast(ws.room,{t:'give',from:ws.uid,to:m.to,item:String(m.item||'').slice(0,48),n:Math.max(1,Math.min(5000,Number(m.n)||1))});
    }
  });
  ws.on('close',()=>remove(ws)); ws.on('error',()=>remove(ws));
});
setInterval(()=>{for(const ws of wss.clients){if(ws.isAlive===false){ws.terminate();continue;}ws.isAlive=false;ws.ping();}},25000);
wss.on('connection',ws=>{ws.isAlive=true;ws.on('pong',()=>ws.isAlive=true);});
server.listen(PORT,'0.0.0.0',()=>console.log(`Boom Survival relay listening on ${PORT} | max ${MAX_PLAYERS}`));
