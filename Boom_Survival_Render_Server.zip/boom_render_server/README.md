# Boom Survival server (Render)

This is a lightweight WebSocket relay. It is a server component only; the Boom Survival HTML client must be modified to use this WebSocket protocol before players can connect to it.

## Deploy on Render from a GitHub repository
1. Upload these files to a new GitHub repository.
2. Render Dashboard → New → Web Service → connect that repository.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. Instance type: Free.
6. Optional environment variable: `MAX_PLAYERS=15`.
7. Deploy. Test `https://YOUR-SERVICE.onrender.com/health`.

## Protocol
- Client sends `{t:"join", room:"main", name:"Nickname"}`
- Server responds `{t:"hello", id, maxPlayers}` and `{t:"joined", room, id, players}`
- Player update `{t:"player", p:[x,y,z], h:hp}`; server broadcasts `{t:"player", id,n,p,h}`
- Chat `{t:"chat", m:"message"}`; server broadcasts with id/name
- Room capacity defaults to 15.

Render Free services may sleep after 15 minutes without inbound HTTP/WebSocket traffic and can restart. Not an authoritative anti-cheat server. No account/password authentication is implemented here.
